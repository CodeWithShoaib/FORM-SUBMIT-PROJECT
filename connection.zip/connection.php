<?php
$username="root";
$password="";
$server='localhost';
$db='talhayoutube';
$con=mysqli_connect($server,$username,$password,$db);
if($con){
    // echo "true";
    ?>
    <script>
        alert("your connection successfull");
    </script>
    <?php
}else{
    // echo "false";
    die("no connection".mysqli_connect_error());
}


?>